// Todas las clases comienzan por mayuscula
class Alumno{

    // propiedades, atributos, campos, caracteristicas
    nombre;
    apellido;
    nota;

    // constructor
    constructor(nombre, apellido, nota){
        this.nombre = nombre;
        this.apellido = apellido;
        this.nota = nota;
    }

    // metodos, acciones, funciones
    cambiarNota(nuevaNota){
        this.nota = nuevaNota;
    }

    mostrarInfo(){
        return "Nombre: " + this.nombre + " Apellido: " + this.apellido +
            " Nota: " + this.nota;
    }
}