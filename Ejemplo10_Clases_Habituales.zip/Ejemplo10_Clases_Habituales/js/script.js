function matematicas(){
    document.write("Log 1000: " + Math.log(1000) + "<br/>");
    document.write("exp 3: " + Math.exp(3) + "<br/>");
    document.write("raiz de 25: " + Math.sqrt(25) + "<br/>");
    document.write("potencia 2 elevado 4: " + Math.pow(2,4) + "<br/>");
    document.write("absoluto -65434: " + Math.abs(-65434) + "<br/>");
    document.write("floor -7.2443: " + Math.floor(-7.2443) + "<br/>");
    document.write("floor 7.2443: " + Math.floor(7.2443) + "<br/>");
    document.write("ceil -7.2443: " + Math.ceil(-7.2443) + "<br/>");
    document.write("ceil 7.2443: " + Math.ceil(7.2443) + "<br/>");
    document.write("round -7.2443: " + Math.round(-7.2443) + "<br/>");
    document.write("round 7.2443: " + Math.round(7.2443) + "<br/>");
    document.write("random: " + Math.random() + "<br/>");
    document.write("random 0-100: " + Math.random() * 100 + "<br/>");
    document.write("cos 100: " + Math.cos(100) + "<br/>");
    document.write("max: " + Math.max(34,1,89,23,78) + "<br/>");
    document.write("min: " + Math.min(34,1,89,23,78) + "<br/>");
    document.write("PI: " + Math.PI + "<br/>");
    document.write("E: " + Math.E + "<br/>");
}

function textos(){
    var texto = "Esto es un texto para probar los metodos String";
    document.write("fromCharCode 74: " + String.fromCharCode(74) + "<br/>");
    document.write("charCodeAt 3: " + texto.charCodeAt(3) + "<br/>");
    document.write("indexOf a: " + texto.indexOf('a') + "<br/>");
    document.write("indexOf a desde 19: " + texto.indexOf('a',19) + "<br/>");
    document.write("lastIndexOf a: " + texto.lastIndexOf('a') + "<br/>");
    document.write("substr 3,6: " + texto.substr(3,6) + "<br/>");
    document.write("slice 3,6: " + texto.slice(3,6) + "<br/>");
    document.write("slice 3: " + texto.slice(3) + "<br/>");
    document.write("substring 3,6: " + texto.substring(3,6) + "<br/>");
    document.write("substring 3: " + texto.substring(3) + "<br/>");
    var datos = "Anabel Vegas Caceres".split(' ');
    document.write("Nombre: " + datos[0] + "<br/>");
    document.write("Apellido 1: " + datos[1] + "<br/>");
    document.write("Apellido 2: " + datos[2] + "<br/>");
    document.write("Dia: " + "29/11/2022".split('/')[0] + "<br/>");
    document.write("Mes: " + "29/11/2022".split('/')[1] + "<br/>");
    document.write("Año: " + "29/11/2022".split('/')[2] + "<br/>");
    document.write("Mayusculas: " + texto.toUpperCase() + "<br/>");
    document.write("Minusculas: " + texto.toLowerCase() + "<br/>");
}

function fechas(){
    var hoy = new Date();

    document.write("getTime: " + hoy.getTime() + "<br/>");
    document.write("getTimezoneOffset: " + hoy.getTimezoneOffset() + "<br/>");
    document.write("getDay: " + hoy.getDay() + "<br/>");
    document.write("getDate: " + hoy.getDate() + "<br/>");
    document.write("getMonth: " + hoy.getMonth() + "<br/>");
    document.write("getYear: " + hoy.getYear() + "<br/>");
    document.write("getFullYear: " + hoy.getFullYear() + "<br/>");
    document.write("getHours: " + hoy.getHours() + "<br/>");
    document.write("getMinutes: " + hoy.getMinutes() + "<br/>");
    document.write("getSeconds: " + hoy.getSeconds() + "<br/>");
    document.write("getMilliseconds: " + hoy.getMilliseconds() + "<br/>");
}