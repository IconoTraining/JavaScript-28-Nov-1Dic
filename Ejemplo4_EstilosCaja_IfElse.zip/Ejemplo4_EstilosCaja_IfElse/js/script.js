// Variables
var estiloBorde = false;   // No tiene borde
var estiloColor = false;   // No tiene color
var estiloSombra = false;   // No tiene sombra

function borde(){
    // Si no tiene borde lo pongo, si lo tiene se lo quito
    if (estiloBorde == false){
        document.getElementById("cuadrado").style.border = "5px solid blue";
        estiloBorde = true;  // Ahora tiene borde
    } else {
        document.getElementById("cuadrado").style.border = "none";
        estiloBorde = false;  // Ahora no tiene borde
    }
}

function color(){
    if (!estiloColor){
        document.getElementById("cuadrado").style.backgroundColor = "pink";
    } else {
        document.getElementById("cuadrado").style.backgroundColor = "gainsboro";
    }
    estiloColor = !estiloColor;
}

function sombra(){
    if (!estiloSombra){
        document.getElementById("cuadrado").className = "sombraCaja";
    } else {
        document.getElementById("cuadrado").className = null;
    }
    estiloSombra = !estiloSombra;
}