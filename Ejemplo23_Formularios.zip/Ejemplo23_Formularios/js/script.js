function mostrar(){
    // Cancelo el evento submit
    event.preventDefault();

    // Mostrar por consola los valores introducidos en el formulario
    console.log("Nombre: " + formulario.nombre.value);
    console.log("PW: " + formulario.pw.value);
    console.log("Apellido: " + formulario.apellido.value);
    console.log("Edad: " + formulario.edad.value);
    console.log("Email: " + formulario.email.value);
    console.log("Web: " + formulario.web.value);
    console.log("Telefono: " + formulario.telefono.value);
    console.log("Nacimiento: " + formulario.nacimiento.value);
    console.log("Sexo: " + formulario.sexo.value);
    console.log("Estudios: " + 
        formulario.estudios.options[formulario.estudios.selectedIndex].text);
    
    for (var i in formulario.cursos.options){
        if (formulario.cursos.options[i].selected){
            console.log("Curso realizado: " + 
                formulario.cursos.options[i].text);
        }
    }
}


function rellenar(){

    // en el select de nivel de estudios agregar:
    //   - master
    //   - doctorado
    var opt = new Option("Master", "master");
    formulario.estudios.options[formulario.estudios.options.length] = opt;
    var opt = new Option("Doctorado", "doctorado");
    formulario.estudios.options[formulario.estudios.options.length] = opt;


    // en el select de cursos agregar:
    //   - Java
    //   - Python
    var opt = new Option("Java", "java");
    formulario.cursos.options[formulario.cursos.options.length] = opt;
    var opt = new Option("Python", "python");
    formulario.cursos.options[formulario.cursos.options.length] = opt;


    // poner un sitio web por defecto y modificar el campo como solo lectura
    formulario.web.value = "http://www.google.es";
    formulario.web.readOnly = true;

}