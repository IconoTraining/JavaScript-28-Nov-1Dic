// Una clase encapsulada define todas sus propiedades como privadas
// y solo se accede a ellas a través de los métodos get() y set() publicos
class FechaEncapsulada{

    // propiedades privadas
    #dia;
    #mes;
    #anyo;

    constructor(dia, mes, anyo){
        this.setDia(dia);
        this.setMes(mes);
        this.setAnyo(anyo);
    }

    getDia(){
        return this.#dia;
    }

    setDia(dia){
        if (dia > 0 && dia <= 31){
            this.#dia = dia;
        } else {
            alert("Dia no valido");
        }
    }

    getMes(){
        return this.#mes;
    }

    setMes(mes){
        if (mes > 0 && mes <= 12){
            this.#mes = mes;
        } else {
            alert("Mes no valido");
        }
    }

    getAnyo(){
        return this.#anyo;
    }

    setAnyo(anyo){
        if (anyo == 2022 || anyo == 2023){
            this.#anyo = anyo;
        } else {
            alert("Año no valido");
        }
    }

    mostrar(){
        return this.#dia + "/" + this.#mes + "/" + this.#anyo;
    }
}