class Rectangulo extends Figura{

    base;
    altura;

    constructor(x,y,base, altura){
        super(x,y);   // invocamos al constructor de la superclase
        this.base = base;
        this.altura = altura;
    }

    // Sobreescribir el metodo area
    area(){
        return this.base * this.altura;
    }

    // Sobreescribir el metodo mostrar
    mostrar(){
        return super.mostrar() + 
            " Base: " + this.base + " Altura: " + this.altura;
    }
}