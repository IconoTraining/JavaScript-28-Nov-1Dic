let nombre = 'Pepito';  // string
document.write(nombre + ", tipo: " + typeof(nombre) + "<br/>");

let numero = 6.45;  // number
document.write(numero + ", tipo: " + typeof(numero) + "<br/>");

let soltero = true;
document.write(soltero + ", tipo: " + typeof(soltero) + "<br/>");

let hoy = new Date();
document.write(hoy + ", tipo: " + typeof(hoy) + "<br/>");

let variable
document.write(variable + ", tipo: " + typeof(variable) + "<br/>");

// Bases numericas
let hexadecimal = 0x123456;
document.write("Hexadecimal: " + hexadecimal + "<br/>");

let octal = 0123456;
document.write("Octal: " + octal + "<br/>");

let binario = 0b0101011;
document.write("Binario: " + binario + "<br/>");