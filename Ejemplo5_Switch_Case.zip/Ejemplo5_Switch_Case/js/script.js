function cambiarColor(event){

    switch (event.target.id) {   // recuperar el id del boton pulsado
        case "btn1":
            //alert("rojo");
            document.getElementById("btn1").className = "rojo";
            break;
    
        case "btn2":
            //alert("verde");
            document.getElementById("btn2").className = "verde";
            break;
        
        case "btn3":
            //alert("azul");
            document.getElementById("btn3").className = "azul";
            break;
            
        default:
            break;
    }
}
