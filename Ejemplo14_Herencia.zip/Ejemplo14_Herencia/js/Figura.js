class Figura{

    // propiedades protected
    _x;
    _y;

    constructor(x, y){
        this._x = x;
        this._y = y;
    }

    area(){
        return 0;
    }

    posicion(){
        return "[" + this._x + "," + this._y + "]";
    }

    mostrar(){
        return "X: " + this._x + " Y: " + this._y;
    }
}