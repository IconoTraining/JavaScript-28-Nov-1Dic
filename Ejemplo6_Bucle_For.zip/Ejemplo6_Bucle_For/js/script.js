function cargarProvincias(){

    // Crear un array de provincias
    var arrayProvincias = ['Madrid', 'Valencia', 'Sevilla', 'Toledo'];

    // Recorrer el array
    for(let indice in arrayProvincias){
        // Por cada provincia genero <option value="indice">provincia</option>
        document.getElementById("provincias").innerHTML += 
            "<option value=" +indice +">" +arrayProvincias[indice] + "</option>";
    }
}

function cargarPoblaciones(){
    var seleccionado = document.getElementById("provincias").selectedIndex;
    var arrayPoblaciones = null;

    switch (seleccionado) {
        case 1:
            arrayPoblaciones = ['Getafe', 'Parla', 'Las Rozas'];
            break;
    
        case 2:
            arrayPoblaciones = ['Gandia', 'Oliva'];
            break;
        
        case 3:
            arrayPoblaciones = ['Dos Hermanas', 'Espartinas', 'Los Palacios'];
            break;
        
        case 4:
            arrayPoblaciones = ['Talavera', 'Trillo', 'Cebolla'];
            break;
    }

    // Limpiamos todas las opciones anteriores del select de poblaciones
    document.getElementById("poblaciones").innerHTML =
        "<option>-- Selecciona --</option>"; 

    // Recorrer el array de poblaciones
    for (let indice in arrayPoblaciones){
        var opt = new Option(arrayPoblaciones[indice], indice);
        document.getElementById("poblaciones").options[parseInt(indice)+1] = opt;
    }

}