class Circulo extends Figura{

    radio;

    constructor(x,y,radio){
        super(x,y);   // invocamos al constructor de la superclase
        this.radio = radio;
    }

    // Sobreescribir el metodo area
    area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    // Sobreescribir el metodo mostrar
    mostrar(){
        return super.mostrar() + " Radio: " + this.radio;
    }
}