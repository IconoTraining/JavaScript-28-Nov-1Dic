function mostrarTipo(){
    if (document.getElementById("conducir_si").checked){
        document.getElementById('tipo').style.display = 'block';
    } else {
        document.getElementById('tipo').style.display = 'none';
    }
}